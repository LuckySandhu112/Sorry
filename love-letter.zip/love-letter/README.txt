HOW TO FINISH SETTING THIS UP
================================

1. ADD YOUR PHOTOS
   Drop 5-7 real photos into the "images" folder and name them exactly:
     photo1.jpg
     photo2.jpg
     photo3.jpg
     photo4.jpg
     photo5.jpg
     photo6.jpg
   (You can use .png too — just update the file extension in index.html's
   <img src="images/photo1.jpg" ...> tags to match.)

   Until you add real photos, each gallery tile will gracefully show a soft
   pink gradient with a little heart instead of a broken image icon, so the
   site still looks nice if you open it before adding them.

2. ADD BACKGROUND MUSIC (optional)
   Drop an MP3 into the "music" folder and name it exactly:
     song.mp3
   The music button in the top-right corner starts/stops it — it never
   autoplays with sound, since browsers block that anyway.

3. OPEN IT
   Just double-click index.html to open it in your browser. No build step,
   no server, no installs needed.

4. EDITING THE WORDS
   - All the text lives directly in index.html, inside quotation-free plain
     HTML, organized by section comments like "<!-- 4. LOVE LETTER -->".
   - Colors, fonts and animation timing live in style.css under the
     ":root { ... }" block at the very top if you want to adjust the palette.
   - The playful "NO button" behavior and the YES celebration are both in
     script.js, near the bottom, under "FORGIVE SECTION".

That's it — everything is plain HTML/CSS/JS, so any part of it is safe to
open in VS Code and tweak.
